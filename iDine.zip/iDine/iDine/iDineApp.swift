//
//  iDineApp.swift
//  iDine
//
//  Created by Rana Ijaz Ahmad on 09/08/2023.
//

import SwiftUI

@main
struct iDineApp: App {
    
    @StateObject var order = Order()
    
    var body: some Scene {
        WindowGroup {
            MainView()
                .environmentObject(order)
        }
    }
}
